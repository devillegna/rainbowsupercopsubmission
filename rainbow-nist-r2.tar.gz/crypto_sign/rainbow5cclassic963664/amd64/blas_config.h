/// @file blas_config.h
/// @brief Defining the machine architecture for blas implementations.
///

#ifndef _BLASH_CONFIG_H_
#define _BLASH_CONFIG_H_


#define _BLAS_UINT64_
//#define _BLAS_SSE_
//#define _BLAS_AVX2_

#define NDEBUG


#endif // _BLASH_CONFIG_H_

